from re import L
from flask import Flask, render_template, request, redirect, session

app = Flask(__name__)

app.secret_key="Yolo 420 69"

@app.route('/')
def index():
    if "count" not in session:
        session["count"]=0
    else:
        session['count'] += 1
    return render_template("index.html")

@app.route('/reset')
def reset():
    session.clear()
    return redirect('/')

if __name__=="__main__":
    app.run(debug=True)